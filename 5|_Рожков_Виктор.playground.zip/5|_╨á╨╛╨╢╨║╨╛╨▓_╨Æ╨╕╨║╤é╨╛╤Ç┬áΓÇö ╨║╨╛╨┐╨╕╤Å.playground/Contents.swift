import Foundation
//Состояния окон
enum Windows: String {
    case open = "открыты"
    case close = "закрыты"
}
//Состояния двигателя
enum Motor: String {
    case on = "работает"
    case off = "заглушен"
}

protocol Car: class {
    var carBrend: String { get } //Марка автомобиля
    var maxGasVol: Float { get }  //Объём топливного бака
    var gasVol: Float { get set } // Топлива в данный момент
    var gasConsumption: Float { get } //Расход
    var odometr: Float { get set } // Пробег авто
    var windows: Windows { get set } // Состояние окон
    var motor: Motor { get set } // Состояние двигателя
    // Открываем окна
    func openWindows()
    // Закрываем окна
    func closeWindows()
    // Запускаем двигатель
    func onMotor()
    // Глушим двигатель
    func offMotor()
    // Заправляем топливо
    func refuelCar(liters: Float)
}

extension Car {
    // Открываем окна
    func openWindows(){
        self.windows = .open
    }
    // Закрываем окна
    func closeWindows(){
        self.windows = .close
    }
    // Запускаем двигатель
    func onMotor() {
        if gasVol > 0 {
            print("Двигатель заведён у \(carBrend)\n")
            self.motor = .on
        } else {
            print("Нельзя завести без топлива. Необходимо заправить авто\n")
        }
    }
    // Глушим двигатель
    func offMotor() {
        print("Двигатель заглушен у \(carBrend)\n")
        self.motor = .off
    }
    // Заправляем топливо
    func refuelCar(liters: Float) {
        self.gasVol += liters
        if gasVol >= maxGasVol {
            print("Вы заправили \(maxGasVol), у вас полный бак\n")
            self.gasVol = maxGasVol
        } else {
            print("Вы заправили \(liters) л топлива\n")
        }
    }
}

class TrunkCar: Car {
    
    //Положение кабины
    enum Cabin: String {
        case normalMode = "Походный режим"//Нормальный режим
        case repairMode = "Режим ремонта" //Режим ремонта
    }
    
    let carBrend: String //Марка автомобиля
    let maxGasVol: Float  //Объём топливного бака
    var gasVol: Float { // Топлива в данный момент
        willSet {
            if gasVol <= 50 {
                print("У вас скоро закончится топливо. Осталось \(gasVol) л")
            }
        }
        didSet {
            if gasVol == 0 {
                print("У вас закончилось топливо")
            }
        }
    }
    let gasConsumption: Float  // Расход топлива
    var odometr: Float  // Пробег авто
    var windows: Windows = .close  // Состояние окон (по умолчанию закрыты)
    var motor: Motor = .off  // Состояние двигателя (по умолчанию заглушен)
    let maxCarrying: Float // Грузоподъёмность
    var truckLoad: Float = 0 // Груз на данный момент (по умолчанию 0)
    var cabin: Cabin = .normalMode // Положение кабины
    init(carBrend: String, maxGasVol: Float, gasVol: Float, gasConsumption: Float, odometr: Float, maxCarrying: Float) {
        self.carBrend = carBrend
        self.maxGasVol = maxGasVol
        self.gasVol = gasVol
        self.gasConsumption = gasConsumption
        self.odometr = odometr
        self.windows = .close
        self.motor = .off
        self.maxCarrying = maxCarrying
        self.truckLoad = 0
        self.cabin = .normalMode
    }
    // Загружаем грузовик
    func loadingTheTruck(weight: Float) {
        self.truckLoad += weight
        print("Вы загрузили: \(weight) кг груза\n")
        if truckLoad > maxCarrying {
            print("Превышена максимальная грузоподъёмность! Необходимо разгрузить \(truckLoad - maxCarrying), кг иначе может произойти поломка\n")
        }
    }
    // Разгружаем грузовик
    func unloadingTheTruck(weight: Float) {
        self.truckLoad -= weight
        if truckLoad > 0 {
            print("Выгружено: \(weight) кг груза\n")
        } else if truckLoad < 0 {
            print("Выгружены оставшиеся \(weight + truckLoad) кг груза\n")
            self.truckLoad = 0
        } else {
            print("Нечего выгружать\n")
        }
    }
    
    //Меняем положение кабины на нормальное
    func cabinNormalMode() {
        print("Кабина установлена в походный режим. Можно ехать.\n")
        return cabin = .normalMode
    }
    //Меняем положение кабины на ремонтное
    func cabinRepairMode() {
        print("Кабина установлена в ремонтный режим.\n")
        if motor == .on {
            return motor = .off
        }
        return cabin = .repairMode
    }
    // Запускаем двигатель. Двигатель не заведётся если кабина находится в ремонтном положении
    func onMotor() {
        if gasVol > 0 && cabin == .normalMode {
            print("Двигатель заведён у \(carBrend)\n")
            return motor = .on
        } else if cabin == .repairMode {
            print("Нельзя завести машину с кабиной в режиме ремонта!\n")
        } else {
            print("Нельзя завести без топлива. Необходимо заправить авто\n")
        }
    }
    // Едем. Грузовик не поедет если он перегружен
    func toGo(distance: Float) {
        var maxDistance: Float // Запас хода
        maxDistance  = gasVol / (gasConsumption / 100)
        if maxDistance >= distance && motor == .on && truckLoad <= maxCarrying {
            print("Вы проехали: \(distance) км\n")
            odometr += distance
            maxDistance -= distance
            gasVol = maxDistance * (gasConsumption / 100)
        } else if maxDistance < distance && motor == .on && truckLoad <= maxCarrying {
            print("Вы проехали \(maxDistance) км. Необходимо дозаправить авто!\n")
            odometr += maxDistance
            gasVol = 0
            self.motor = .off
        } else if truckLoad > maxCarrying {
            print("Превышена максимальная грузоподъёмность. Чтобы поехать выгрузите \(truckLoad - maxCarrying) кг\n")
        } else {
            print("Заведите двигатель\n")
        }
    }
}

extension TrunkCar: CustomStringConvertible{
    var description: String {
        return " Марка авто: \(carBrend)\n Объём бака: \(maxGasVol) л\n Топлива в баке: \(gasVol) л\n Расход л/100 км: \(gasConsumption)\n Запас хода: \(gasVol / (gasConsumption / 100)) км\n Пробег: \(odometr) км\n Окна: \(windows.rawValue)\n Двигатель: \(motor.rawValue)\n Положение кабины: \(cabin.rawValue)\n Максимальная грузоподъёмность: \(maxCarrying) кг\n Груз: \(truckLoad) кг\n"
    }
}

class SportCar: Car {
    //Режимы езды автомобиля
    enum DrivingMode: String {
        case economy = "Экономичный"
        case normal = "Обычный"
        case sport = "Спортивный"
    }
    //Положение крыши
    enum Roof: String {
        case normal = "Нормальное"
        case folded = "Сложена"
    }
    
    let carBrend: String //Марка автомобиля
    let maxGasVol: Float  //Объём топливного бака
    var gasVol: Float { // Топлива в данный момент
        willSet {
            if gasVol <= 10 {
                print("У вас скоро закончится топливо. Осталось \(gasVol) л")
            }
        }
        didSet {
            if gasVol == 0 {
                print("У вас закончилось топливо")
            }
        }
    }
    var consumption: Float //Расход топлива от режима езды
    let gasConsumption: Float // Расход топлива
    var odometr: Float  // Пробег авто
    var drivingMode: DrivingMode = .normal
    var windows: Windows = .close  // Состояние окон (по умолчанию закрыты)
    var motor: Motor = .off  // Состояние двигателя (по умолчанию заглушен)
    var roof: Roof = .normal
    
    init(carBrend: String, maxGasVol: Float, gasVol: Float, gasConsumption: Float, odometr: Float){
        self.carBrend = carBrend
        self.maxGasVol = maxGasVol
        self.gasVol = gasVol
        self.gasConsumption = gasConsumption
        self.consumption = gasConsumption
        self.odometr = odometr
        self.drivingMode = .normal
        self.windows = .close
        self.motor = .off
        self.roof = .normal
    }
    //Прячем крышу
    func noRoof() {
        print("Крыша сложена\n")
        self.roof = .folded
    }
    //Возвращаем крышу
    func isRoof() {
        print("Крыша разложена\n")
        self.roof = .normal
    }
    //Выбираем режим езды
    //Экономичный
    func economyDrivingMode() {
        self.consumption = gasConsumption * 0.8
        self.drivingMode = .economy
    }
    //Обычный
    func normalDrivingMode() {
        self.consumption = gasConsumption * 1
        self.drivingMode = .normal
    }
    //Спортивный
    func sportDrivingMode() {
        self.consumption = gasConsumption * 1.25
        self.drivingMode = .sport
    }
    
    // Едем
    func toGo(distance: Float) {
        var maxDistance: Float // Запас хода
        maxDistance  = gasVol / (consumption / 100)
        if maxDistance >= distance && motor == .on {
            print("Вы проехали: \(distance) км")
            odometr += distance
            maxDistance -= distance
            gasVol = maxDistance * (consumption / 100)
        } else if maxDistance < distance && motor == .on {
            print("Вы проехали \(maxDistance) км. Необходимо дозаправить авто!")
            odometr += maxDistance
            gasVol = 0
            self.motor = .off
        } else {
            print("Заведите двигатель")
        }
    }
}

extension SportCar: CustomStringConvertible{
    var description: String {
        return " Марка авто: \(carBrend)\n Объём бака: \(maxGasVol) л\n Топлива в баке: \(gasVol) л\n Расход л/100 км: \(consumption)\n Пробег: \(odometr) км\n Окна: \(windows.rawValue)\n Запас хода: \(gasVol / (consumption / 100)) км\n Двигатель: \(motor.rawValue)\n Режим езды: \(drivingMode.rawValue)\n Положение крыши: \(roof.rawValue)\n"
    }
}

var volvo = TrunkCar(carBrend: "Volvo", maxGasVol: 400, gasVol: 400, gasConsumption: 25, odometr: 76000, maxCarrying: 20000)

print(volvo)
volvo.openWindows()
volvo.onMotor()
volvo.loadingTheTruck(weight: 25000)
volvo.closeWindows()
volvo.toGo(distance: 100)
volvo.unloadingTheTruck(weight: 5000)
volvo.toGo(distance: 1500)
print(volvo)

var ferrari = SportCar(carBrend: "Ferrari 488 Spider", maxGasVol: 60, gasVol: 50, gasConsumption: 11.5, odometr: 10000)

print(ferrari)
ferrari.openWindows()
ferrari.onMotor()
print(ferrari)
ferrari.sportDrivingMode()
print(ferrari)
ferrari.toGo(distance: 330)
ferrari.economyDrivingMode()
ferrari.normalDrivingMode()
ferrari.toGo(distance: 10)
print(ferrari)

