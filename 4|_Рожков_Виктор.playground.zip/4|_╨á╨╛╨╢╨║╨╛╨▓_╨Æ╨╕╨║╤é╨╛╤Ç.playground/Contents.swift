import UIKit
import Foundation

class Car {
    
    //Состояния окон
    enum Windows: String {
        case open = "открыты"
        case close = "закрыты"
    }
    
    //Состояния двигателя
    enum Motor: String {
        case on = "работает"
        case off = "заглушен"
    }
    
    let carBrend: String //Марка автомобиля
    let maxGasVol: Double //Объём топливного бака
    var gasVol: Double {  // Топлива в данный момент
        willSet {
            if gasVol <= 20 {
                print("У вас скоро закончится топливо. Осталось \(gasVol) л")
            }
        }
        didSet {
            if gasVol == 0 {
                print("У вас закончилось топливо")
            }
        }
    }
    let gasConsumption: Double // Расход топлива
    var odometr: Double // Пробег авто
    var windows: Windows = .close // Состояние окон (по умолчанию закрыты)
    var motor: Motor = .off // Состояние двигателя (по умолчанию заглушен)
    
    var description: String {
        return "Марка авто: \(carBrend), Объём бака: \(maxGasVol), Топлива в баке: \(gasVol), Расход л/100 км: \(gasConsumption),  Пробег: \(odometr), Окна: \(windows.rawValue), Двигатель: \(motor.rawValue)"
    }
    
    init(carBrend: String, maxGasVol: Double, gasVol: Double, gasConsumption: Double) {
        self.carBrend = carBrend
        self.maxGasVol = maxGasVol
        self.gasVol = gasVol
        self.gasConsumption = gasConsumption
        self.odometr = 0
        self.windows = .close
        self.motor = .off
    }
    
    // Открываем окна
    func openWindows(){
        return windows = .open
    }
    
    // Закрываем окна
    func closeWindows(){
        return windows = .close
    }
    
    // Запускаем двигатель
    func onMotor() {
        if gasVol > 0 {
            print("Двигатель заведён у \(carBrend)")
            return motor = .on
        } else {
            print("Нельзя завести без топлива. Необходимо заправить авто")
        }
    }
    
    // Глушим двигатель
    func offMotor() {
        print("Двигатель заглушен у \(carBrend)")
        return motor = .off
    }
    
    // Заправляем топливо
    func refuelCar(liters: Double) {
        self.gasVol += liters
        if gasVol >= maxGasVol {
            print("Вы заправили \(maxGasVol), у вас полный бак")
            gasVol = maxGasVol
        } else {
            print("Вы заправили \(liters) л топлива")
        }
    }
    
    // Едем
    func toGo(distance: Double) {
        var maxDistance: Double // Запас хода
        maxDistance  = gasVol / (gasConsumption / 100)
        if maxDistance >= distance && motor == .on {
            print("Вы проехали: \(distance) км")
            odometr += distance
            maxDistance -= distance
            gasVol = maxDistance * (gasConsumption / 100)
        } else if maxDistance < distance && motor == .on {
            print("Вы проехали \(maxDistance) км. Необходимо дозаправить авто!")
            odometr += maxDistance
            gasVol = 0
            offMotor()
        } else {
            print("Заведите двигатель")
        }
    }
}

class TrunkCar: Car {
   
    //Положение кабины
    enum Cabin: String {
        case normalMode = "Походный режим"//Нормальный режим
        case repairMode = "Режим ремонта" //Режим ремонта
    }
    
    let maxCarrying: Double // Грузоподъёмность
    var truckLoad: Double = 0 // Груз на данный момент (по умолчанию 0)
    var cabin: Cabin // Положение кабины
    
    override var description: String {
        return "Марка авто: \(carBrend), Объём бака: \(maxGasVol), Топлива в баке: \(gasVol), Расход л/100 км: \(gasConsumption), Запас хода: \(gasVol / (gasConsumption / 100)),  Пробег: \(odometr), Окна: \(windows.rawValue), Двигатель: \(motor.rawValue), Максимальная грузоподъёмность: \(maxCarrying), Груз: \(truckLoad), Положение кабины: \(cabin.rawValue)"
    }
    
    init(carBrend: String, maxGasVol: Double, gasVol: Double, gasConsumption: Double, maxCarrying: Double, truckLoad: Double = 0) {
        self.cabin = .normalMode
        self.maxCarrying = maxCarrying
        self.truckLoad = truckLoad
        super.init(carBrend: carBrend, maxGasVol: maxGasVol, gasVol: gasVol, gasConsumption: gasConsumption)
    }
    
    // Загружаем грузовик
    func loadingTheTruck(weight: Double) {
        self.truckLoad += weight
        print("Вы загрузили: \(weight) кг груза")
        if truckLoad > maxCarrying {
            print("Превышена максимальная грузоподъёмность! Необходимо разгрузить \(truckLoad - maxCarrying), кг иначе может произойти поломка")
        }
    }
    // Разгружаем грузовик
    func unloadingTheTruck(weight: Double) {
        self.truckLoad -= weight
        if truckLoad > 0 {
            print("Выгружено: \(weight) кг груза")
        } else if truckLoad < 0 {
            print("Выгружены оставшиеся \(weight + truckLoad) кг груза")
            self.truckLoad = 0
        } else {
            print("Нечего выгружать")
        }
    }
    
    //Меняем положение кабины на нормальное
    func cabinNormalMode() {
        print("Кабина установлена в походный режим. Можно ехать.")
        return cabin = .normalMode
    }
    //Меняем положение кабины на ремонтное
    func cabinRepairMode() {
        print("Кабина установлена в ремонтный режим.")
        if motor == .on {
            return motor = .off
        }
        return cabin = .repairMode
    }
    
    // Запускаем двигатель. Двигатель не заведётся если кабина находится в ремонтном положении
    override func onMotor() {
        if gasVol > 0 && cabin == .normalMode {
            print("Двигатель заведён")
            return motor = .on
        } else if cabin == .repairMode {
            print("Нельзя завести машину с кабиной в режиме ремонта!")
        } else {
            print("Нельзя завести без топлива. Необходимо заправить авто")
        }
    }

    // Едем. Грузовик не поедет если он перегружен
    override func toGo(distance: Double) {
        var maxDistance: Double // Запас хода
        maxDistance  = gasVol / (gasConsumption / 100)
        if maxDistance >= distance && motor == .on && truckLoad <= maxCarrying {
            print("Вы проехали: \(distance) км")
            odometr += distance
            maxDistance -= distance
            gasVol = maxDistance * (gasConsumption / 100)
        } else if maxDistance < distance && motor == .on && truckLoad <= maxCarrying {
            print("Вы проехали \(maxDistance) км. Необходимо дозаправить авто!")
            odometr += maxDistance
            gasVol = 0
            offMotor()
        } else if truckLoad > maxCarrying {
            print("Превышена максимальная грузоподъёмность. Чтобы поехать выгрузите \(truckLoad - maxCarrying) кг")
        } else {
            print("Заведите двигатель")
        }
    }
}

class SportCar: Car {
    //Режимы езды автомобиля
    enum DrivingMode: String {
        case economy = "Экономичный"
        case normal = "Обычный"
        case sport = "Спортивный"
    }
    //Положение крыши
    enum Roof: String {
        case normal = "Нормальное"
        case folded = "Сложена"
    }
    
    var drivingMode: DrivingMode = .normal
    var consumption: Double //Расход топлива
    var roof: Roof = .normal
    
    override var description: String {
        return " Марка авто: \(carBrend), Объём бака: \(maxGasVol), Топлива в баке: \(gasVol), Расход л/100 км: \(consumption),  Пробег: \(odometr), Окна: \(windows.rawValue),\n Запас хода: \(gasVol / (consumption / 100)) км, Двигатель: \(motor.rawValue), Режим езды: \(drivingMode.rawValue), Положение крыши: \(roof.rawValue)\n"
    }
    
    override init(carBrend: String, maxGasVol: Double, gasVol: Double, gasConsumption: Double) {
        self.drivingMode = .normal
        self.roof = .normal
        self.consumption = gasConsumption
        super.init(carBrend: carBrend, maxGasVol: maxGasVol, gasVol: gasVol, gasConsumption: gasConsumption)
    }
    
    //Прячем крышу
    func noRoof() {
        print("Крыша сложена")
        return roof = .folded
    }
    //Возвращаем крышу
    func isRoof() {
        print("Крыша разложена")
        return roof = .normal
    }
    //Выбираем режим езды
    //Экономичный
    func economyDrivingMode() {
        self.consumption = gasConsumption * 0.8
        return drivingMode = .economy
    }
    //Обычный
    func normalDrivingMode() {
        self.consumption = gasConsumption * 1
        return drivingMode = .normal
    }
    //Спортивный
    func sportDrivingMode() {
        self.consumption = gasConsumption * 1.25
        return drivingMode = .sport
    }
    
    // Едем
    override func toGo(distance: Double) {
        var maxDistance: Double // Запас хода
        maxDistance  = gasVol / (consumption / 100)
        if maxDistance >= distance && motor == .on {
            print("Вы проехали: \(distance) км")
            odometr += distance
            maxDistance -= distance
            gasVol = maxDistance * (consumption / 100)
        } else if maxDistance < distance && motor == .on {
            print("Вы проехали \(maxDistance) км. Необходимо дозаправить авто!")
            odometr += maxDistance
            gasVol = 0
            offMotor()
        } else {
            print("Заведите двигатель")
        }
    }
}


var ferrari = SportCar(carBrend: "Ferrari 488 Spider", maxGasVol: 60, gasVol: 50, gasConsumption: 11.4)
print(ferrari.description)
ferrari.onMotor()
ferrari.noRoof()
ferrari.sportDrivingMode()
print(ferrari.description)
ferrari.economyDrivingMode()
print(ferrari.description)
ferrari.toGo(distance: 530)
print(ferrari.description)
ferrari.toGo(distance: 10)
print(ferrari.description)
ferrari.refuelCar(liters: 60)

var fordMustang = SportCar(carBrend: "Ford Mustang", maxGasVol: 60, gasVol: 60, gasConsumption: 12)
print(fordMustang.description)
fordMustang.onMotor()
fordMustang.toGo(distance: 600)

var volvo = TrunkCar(carBrend: "Volvo", maxGasVol: 200, gasVol: 350, gasConsumption: 25, maxCarrying: 30000)
print(volvo.description)
volvo.cabinRepairMode()
volvo.onMotor()
print(volvo.description)
volvo.cabinNormalMode()
volvo.onMotor()
volvo.loadingTheTruck(weight: 35000)
volvo.toGo(distance: 500)
volvo.unloadingTheTruck(weight: 7000)
volvo.toGo(distance: 1375)
print(volvo.description)
