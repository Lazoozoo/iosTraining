import UIKit

class Milk {
    var number: Float // Количество пачек(бутылок)
    var price: Float //Цена
    
    init(number: Float, price: Float) {
        self.number = number
        self.price = price
    }
    
    func calculateLotPrice() -> Float {
        return number * price
    }

}

struct Queue<T: Milk> {
    
    private var elements: [T] = []
    
    mutating func push(_ element: T) {
        elements.append(element)
    }
    
    mutating func pop() -> T? {
        guard elements.count > 0 else { return nil }
        return elements.removeFirst()
    }
    
    func totalPrice() {
        guard elements.count > 0 else { return }
        var totalPrice: Float = 0
        elements.forEach { totalPrice += $0.calculateLotPrice() }
        print("Стоимость всех партий молока: ", totalPrice)
    }
// Не смог разобраться как отфильтровать элементы коллекции по конкретному свойству, например цена(price)!!!!!!!!!
//    let num: (Float) -> Bool = { (element: Float) -> Bool in
//        return element < 1.5
//    }
//    func filterPrice(array: [T], predicate: (Float) -> Bool) -> [T] {
//        var tmpArray = [T]()
//
//        for element in array {
//            if predicate(element) {
//                tmpArray.append(element)
//            }
//        }
//
//        return tmpArray
//    }
}
var queue = Queue<Milk>()
queue.push(Milk(number: 150, price: 1.1))
queue.push(Milk(number: 70, price: 1.5))
queue.push(Milk(number: 50, price: 1.8))
queue.push(Milk(number: 125, price: 0.9))
queue.push(Milk(number: 110, price: 2))
queue.totalPrice()
queue.pop()
queue.totalPrice()
