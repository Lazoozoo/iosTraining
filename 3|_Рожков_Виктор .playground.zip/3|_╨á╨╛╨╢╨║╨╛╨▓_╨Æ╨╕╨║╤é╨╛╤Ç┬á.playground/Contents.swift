import Foundation
import UIKit

//Состояния двигателя
enum Motor: String {
    case on = "работает"
    case off = "заглушен"
}

struct Truck {
    //Цвета автомобиля
    enum CarColors: String {
        case white = "Белый"
        case black = "Чёрный"
        case blue = "Синий"
        case red = "Красный"
        case green = "Зелёный"
        case grey = "Серый"
        case orange = "Оранжевый"
    }
    //Состояния окон
    enum Windows: String {
        case open = "открыты"
        case close = "закрыты"
    }
    
    //Свойства автомобиля
    let truckBrand: String //Марка грузовика
    let yearOfIssue: Int // Год выпуска
    var truckColor: CarColors // Цвет грузовика
    let maxCarrying: Double // Грузоподъёмность
    var truckLoad: Double = 0 // Груз на данный момент (по умолчанию 0)
    var windows: Windows = .close // Состояние окон (по умолчанию закрыты)
    var truckMotor: Motor = .off // Состояние двигателя (по умолчанию заглушен)
    
    var description: String {
        return "Марка авто: \(truckBrand), Год выпуска: \(yearOfIssue), Цвет авто: \(truckColor.rawValue), Максимальная грузоподъёмность(кг): \(maxCarrying),  Загруженность(кг): \(truckLoad), Окна: \(windows.rawValue), Двигатель: \(truckMotor.rawValue)"
    }
    
    init(truckBrand: String = "Volvo", yearOfIssue: Int = 2018, truckColor: CarColors, maxCarrying: Double, truckLoad: Double = 7000, windows: Windows, motor: Motor){
        self.truckBrand = truckBrand
        self.yearOfIssue = yearOfIssue
        self.truckColor = truckColor
        self.maxCarrying = maxCarrying
        self.truckLoad = truckLoad
        self.windows = windows
        self.truckMotor = motor
    }
    
    init(truckBrand: String = "Kamaz", yearOfIssue: Int = 2015, maxCarrying: Double = 20000, truckLoad: Double){
        self.truckBrand = truckBrand
        self.yearOfIssue = yearOfIssue
        self.truckColor = .red
        self.maxCarrying = maxCarrying
        self.truckLoad = truckLoad
        self.windows = .close
        self.truckMotor = .off
    }
    // Открываем окна у грузовика
    mutating func openWin(){
        return windows = .open
    }
    // Закрываем окна у грузовика
    mutating func closeWin(){
        return windows = .close
    }
    // Запускаем двигатель
    mutating func onMotor() {
        return truckMotor = .on
    }
    // Глушим двигатель
    mutating func offMotor() {
        return truckMotor = .off
    }
    // Загружаем грузовик
    mutating func loadingTheTruck(weight: Double) {
        self.truckLoad += weight
        print("Вы загрузили: \(weight) кг груза")
        if self.truckLoad > maxCarrying {
            print("Превышена максимальная грузоподъёмность! Необходимо разгрузить \(self.truckLoad - maxCarrying), кг иначе может произойти поломка")
        }
    }
    // Разгружаем грузовик
    mutating func unloadingTheTruck(weight: Double) {
        self.truckLoad -= weight
        if self.truckLoad > 0 {
            print("Выгружено: \(weight) кг груза")
        } else if self.truckLoad < 0 {
            print("Выгружены оставшиеся \(weight + self.truckLoad) кг груза")
            self.truckLoad = 0
        } else {
            print("Нечего выгружать")
        }
    }
}

struct Car {
    
    let maxGasVol: Double //Объём топливного бака
    var gasVol: Double {  // Топлива в данный момент
        willSet {
            if gasVol <= 10 {
                print("У вас скоро закончится топливо. Осталось \(gasVol) л")
            }
        }
        didSet {
            if gasVol == 0 {
                print("У вас закончилось топливо")
            }
        }
    }
    let gasConsumption: Double // Расход топлива
    var odometr: Double // Пробег авто
    var carMotor: Motor = .off // Состояние двигателя
   
    var description: String {
        return "Объём бака: \(maxGasVol) л, Топлива в баке: \(gasVol) л, Расход топлива: \(gasConsumption) л/100 км, Запас хода: \(gasVol / (gasConsumption / 100)),  Пробег: \(odometr), Двигатель: \(carMotor.rawValue)"
    }
    
    // Запускаем двигатель
    mutating func onMotor() {
        if gasVol > 0 {
            print("Двигатель заведён")
            return carMotor = .on
        } else {
            print("Нельзя завести без топлива. Необходимо заправить авто")
        }
    }
    // Глушим двигатель
    mutating func offMotor() {
        print("Двигатель заглушен")
        return carMotor = .off
    }
    // Едем
    mutating func toGo(distance: Double) {
        var maxDistance: Double // Запас хода
        maxDistance  = gasVol / (gasConsumption / 100)
        if maxDistance >= distance && carMotor == .on {
            print("Вы проехали: \(distance) км")
            odometr += distance
            maxDistance -= distance
            gasVol = maxDistance * (gasConsumption / 100)
        } else if maxDistance < distance && carMotor == .on {
            print("Вы проехали \(maxDistance) км. Необходимо дозаправить авто!")
            odometr += maxDistance
            gasVol = 0
            offMotor()
        } else {
            print("Заведите двигатель")
        }
    }
    // Заправляем топливо
    mutating func refuelCar(liters: Double) {
        self.gasVol += liters
        if gasVol >= maxGasVol {
            print("Вы заправили \(maxGasVol), у вас полный бак")
            gasVol = maxGasVol
        } else {
            print("Вы заправили \(liters) л топлива")
        }
    }
}

var car = Car(maxGasVol: 60, gasVol: 40, gasConsumption: 10, odometr: 0, carMotor: .off)
print(car.description)
car.onMotor()
print(car.description)
car.toGo(distance: 300)
print(car.description)
car.toGo(distance: 15)
print(car.description)
car.toGo(distance: 70)
print(car.description)
car.toGo(distance: 40)
car.refuelCar(liters: 70)
print("\(car.description)\n")

var truck = Truck(truckLoad: 10000)
print(truck.description)
truck.loadingTheTruck(weight: 17000)
truck.openWin()
truck.onMotor()
print(truck.description)
truck.unloadingTheTruck(weight: 2000)
print(truck.description)
truck.unloadingTheTruck(weight: 70500)
print("\(truck.description)\n")

var truck1 = Truck(truckColor: .blue, maxCarrying: 35000, windows: .open, motor: .on)
print(truck1.description)
truck1.loadingTheTruck(weight: 4000)
print(truck1.description)


