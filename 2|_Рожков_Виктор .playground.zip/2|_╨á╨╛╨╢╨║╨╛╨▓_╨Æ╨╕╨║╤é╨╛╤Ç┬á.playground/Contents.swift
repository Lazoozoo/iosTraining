import Foundation
//Задание 2.1 Функция для проверки: делится ли число на 2 без остатка (чётное число или нечётное)
func evenOdd(a x: Int) -> Bool {
    if (x % 2 == 0) {
        return true
    } else {
        return false
    }
}


//Задание 2.2 Функция для проверки: делится ли число на 3 без остатка
func dividedByThree(a x: Int) -> Bool {
    if (x % 3 == 0) {
        return true
    } else {
        return false
    }
}


//2.3 Создаём массив из 100 элементов
var numbers: [Int] = []
for i in 1...100 {
    numbers.append(i)
}


//2.4 Удаляем из массива, созданного в задании 2.3 все чётные числа и те, что не делятся на 3 без остатка с помощью функций dividedByThree() и evenOdd()
numbers.removeAll(where: { !dividedByThree(a: $0) })
numbers.removeAll(where: { evenOdd(a: $0) })
print(numbers)


//2.5 Добавляем 100 новых чисел Фибоначчи в массив.
func fibonacci(n: Int) -> [Decimal] {
    var fibN: [Decimal] = [1, 1]
    while fibN.count < n {
        fibN.append(fibN[ fibN.count - 1 ] + fibN[ fibN.count - 2 ])
    }
    return fibN
}
print(fibonacci(n: 100))
print("Добавлено чисел Фибоначчи: \(fibonacci(n: 100).count)")


// 2.6 Добавляем в массив 100 простых чисел
//Функция для проверки простое число или нет
func isPrime(_ number: Int) -> Bool {
    return number > 1 && !(2..<number).contains { number % $0 == 0 }
}

var primes: [Int] = [2]
var p: Int = 2
while primes.count < 100 {
    p += 1
    if isPrime(p) {
        primes.append(p)
    }
}
print(primes)
print("Добавлено простых чисе: \(primes.count)")












