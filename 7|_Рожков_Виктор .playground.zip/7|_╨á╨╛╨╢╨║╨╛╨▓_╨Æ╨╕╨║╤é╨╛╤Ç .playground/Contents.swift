import UIKit

enum CardReader: String {
    case isCard = "Карта вставлена"
    case noCard = "Карта отсутствует"
}
// Возможные ошибки при снятии наличных
enum AtmError: Error {
    case incorrectAmount
    case insufficientFundsAtTheDeposit
    case insufficientCashAtTheATM
    case limitForOneOperationExceeded
    case incorrectBanknoteSelection
    case notEnoughBanknotes10Usd
    case notEnoughBanknotes20Usd
    case notEnoughBanknotes50Usd
    case notEnoughBanknotes100Usd
}

class ATM {
    // Количество банкнот разных номиналов в банкомате
    var count10Usd: UInt
    var count20Usd: UInt
    var count50Usd: UInt
    var count100Usd: UInt
    // Считыватель банковских карт
    var cardReader: CardReader = .noCard
    var customerDeposit: UInt
    
    init(count10Usd: UInt, count20Usd: UInt, count50Usd: UInt, count100Usd: UInt) {
        self.count10Usd = count10Usd
        self.count20Usd = count20Usd
        self.count50Usd = count50Usd
        self.count100Usd = count100Usd
        self.cardReader = .noCard
        self.customerDeposit = 0
    }
    // Вставляем банковскую карту клиента, если в считывателе отсутствует другая карта и возвращаем депозит клиента для дальнейших операций
    func insertCustomerBankCard(deposit: UInt) -> UInt {
        if cardReader == .isCard {
            print("Извлеките карту!")
        } else { self.cardReader = .isCard }
        self.customerDeposit = 0
        self.customerDeposit += deposit
        return customerDeposit
    }
    // Извлекаем банковскую карту
    func extractCustomerBankCard() {
        self.cardReader = .noCard
        print("Заберите карту!")
    }
    // Снимаем наличные: вводим сумму(за раз не более 500), и выбираем номиналы банкнот для выдачи(вписать количество)
    func withdrawCash(cash: UInt, banknotes10Usd: UInt, banknotes20Usd: UInt, banknotes50Usd: UInt, banknotes100Usd: UInt ) throws -> String {
        // Проверяем желаемую сумму на кратность самой маленькой банкноте
        guard cash % 10 == 0 else { throw AtmError.incorrectAmount }
        // Проверяем есть ли запрашиваемая сумма на счёте клиента
        guard cash <= customerDeposit else { throw AtmError.insufficientFundsAtTheDeposit }
        // Сопоставляем средства банкомата с желаемой суммой
        guard ((count10Usd * 10) + (count20Usd * 20) + (count50Usd * 50) + (count100Usd * 100)) >= cash else { throw AtmError.insufficientCashAtTheATM }
        // Снять наличных за одну операцию можно не более 500
        guard cash <= 500 else { throw AtmError.limitForOneOperationExceeded }
        // Проверяем соответствие желаемой суммы сумме номиналов банкнот, которые выбрали
        guard cash == ((banknotes10Usd * 10) + (banknotes20Usd * 20) + (banknotes50Usd * 50) + (banknotes100Usd * 100)) else { throw AtmError.incorrectBanknoteSelection }
        // Проверяем возможность выдачи наличных выбранным номиналом банкнот
        guard banknotes10Usd <= count10Usd else { throw AtmError.notEnoughBanknotes10Usd }
        guard banknotes20Usd <= count20Usd else { throw AtmError.notEnoughBanknotes20Usd }
        guard banknotes50Usd <= count50Usd else { throw AtmError.notEnoughBanknotes50Usd }
        guard banknotes100Usd <= count100Usd else { throw AtmError.notEnoughBanknotes100Usd }
        
        // При отсутствии ошибок операция выполняется
        self.customerDeposit -= cash
        self.count10Usd -= banknotes10Usd
        self.count20Usd -= banknotes20Usd
        self.count50Usd -= banknotes50Usd
        self.count100Usd -= banknotes100Usd
        return "Операция завершена успешно! Получено \(cash) USD"
    }
}

extension ATM: CustomStringConvertible {
    var description: String {
        return "Банкноты в банкомате(шт.):\n 10 USD: \(count10Usd)\n 20 USD: \(count20Usd)\n 50 USD: \(count50Usd)\n 100 USD: \(count100Usd)\n Считыватель карт: \(cardReader.rawValue)\n Ваш депозит: \(customerDeposit) USD\n"
    }
}

var sberbsnkAtm = ATM(count10Usd: 50, count20Usd: 50, count50Usd: 40, count100Usd: 2)
print(sberbsnkAtm)
sberbsnkAtm.insertCustomerBankCard(deposit: 500)
print(sberbsnkAtm)
do {
    try sberbsnkAtm.withdrawCash(cash: 500, banknotes10Usd: 10, banknotes20Usd: 5, banknotes50Usd: 2, banknotes100Usd: 2)
} catch AtmError.incorrectAmount {
    print("Некорректная сумма, доступные банкноты 10, 20, 50, 100  USD")
} catch AtmError.insufficientFundsAtTheDeposit {
    print("На вашем счёте недостаточно средств!")
} catch AtmError.insufficientCashAtTheATM {
    print("В банкомате недостаточно средств! Осталось \((sberbsnkAtm.count10Usd * 10) + (sberbsnkAtm.count20Usd * 20) + (sberbsnkAtm.count50Usd * 50) + (sberbsnkAtm.count100Usd * 100)) USD")
} catch AtmError.limitForOneOperationExceeded {
    print("Превышен лимит 500 USD за одну операцию!")
} catch AtmError.incorrectBanknoteSelection {
    print("Некорректный выбор банкнот. Желаемая сумма не соответствует сумме номиналов банкнот")
} catch AtmError.notEnoughBanknotes10Usd {
    print("Недостаточно банкнот 10 USD. Осталось: \(sberbsnkAtm.count10Usd)")
} catch AtmError.notEnoughBanknotes20Usd {
    print("Недостаточно банкнот 20 USD. Осталось: \(sberbsnkAtm.count20Usd)")
} catch AtmError.notEnoughBanknotes50Usd {
    print("Недостаточно банкнот 50 USD. Осталось: \(sberbsnkAtm.count50Usd)")
} catch AtmError.notEnoughBanknotes100Usd {
    print("Недостаточно банкнот 100 USD. Осталось: \(sberbsnkAtm.count100Usd)")
} catch let error {
    print(error)
}

print(sberbsnkAtm)



